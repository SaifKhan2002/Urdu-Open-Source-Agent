import os, io, asyncio, logging
import numpy as np
from dotenv import load_dotenv

from livekit import agents
from livekit.agents import AgentSession, Agent, RoomInputOptions, WorkerOptions
from livekit.plugins import silero, openai, azure
from livekit.agents.stt import (
    STT, STTCapabilities, SpeechEvent, SpeechEventType, SpeechData, StreamAdapter,
)
from faster_whisper import WhisperModel

load_dotenv(".env")
logging.basicConfig(level=logging.INFO)

# =========================================================
# Globals (optional prewarm; but NOT required)
# =========================================================
_WHISPER = None
_VAD = None

# =========================================================
# Helpers
# =========================================================
def _resample_to_16k_mono(int16_pcm: np.ndarray, sr: int, channels: int) -> np.ndarray:
    if channels > 1:
        int16_pcm = int16_pcm.reshape(-1, channels).mean(axis=1).astype(np.int16)
    audio = int16_pcm.astype(np.float32) / 32768.0
    target_sr = 16000
    new_len = int(round(len(audio) * (target_sr / sr)))
    xp = np.linspace(0, len(audio) - 1, num=len(audio), dtype=np.float32)
    x_new = np.linspace(0, len(audio) - 1, num=new_len, dtype=np.float32)
    return np.interp(x_new, xp, audio).astype(np.float32)

def _ensure_multilingual(name: str) -> str:
    # Convert tiny.en/base.en/etc to multilingual so Urdu is supported
    return name[:-3] if name.endswith(".en") else name

def _mostly_ascii(s: str) -> bool:
    stripped = "".join(ch for ch in s if not ch.isspace() and ch not in ".,?!،۔")
    if not stripped:
        return True
    ascii_count = sum(1 for ch in stripped if ord(ch) < 128)
    return ascii_count / max(1, len(stripped)) > 0.6

def _maybe_gpu():
    try:
        import torch
        if torch.cuda.is_available():
            return "cuda", "float16"
    except Exception:
        pass
    return "cpu", "int8"

_URDU_HOTWORDS = "میں آپ یہ وہ کیا کیوں کیسے کہا ٹھیک جی ہاں نہیں شکریہ السلام علیکم"
_URDU_PROMPT = (
    "براہِ کرم مکمل طور پر اردو رسم الخط میں ٹرانسکرائب کریں۔ "
    "انگریزی حروف استعمال نہ کریں۔ واضح اور درست اُردو لکھیں۔ "
    "اعداد و شمار اور نام بھی اردو میں لکھیں۔"
)

def _load_whisper_if_needed():
    """Lazy-load the Whisper model if _WHISPER is None (so code works without prewarm)."""
    global _WHISPER
    if _WHISPER is not None:
        return _WHISPER

    # Use fewer threads on low-end CPUs so decoding doesn’t stall the loop
    cpu_threads = max(1, (os.cpu_count() or 4) // 2)
    os.environ.setdefault("OMP_NUM_THREADS", str(cpu_threads))
    os.environ.setdefault("MKL_NUM_THREADS", str(cpu_threads))

    model_name = _ensure_multilingual(os.getenv("WHISPER_MODEL", "tiny"))  # tiny or base recommended on CPU
    device, compute_type = _maybe_gpu()
    logging.info(f"[Urdu STT] Loading Whisper '{model_name}' on {device} ({compute_type}), threads={cpu_threads}")
    _WHISPER = WhisperModel(
        model_name,
        device=device,
        compute_type=compute_type,
        cpu_threads=cpu_threads,
        num_workers=1,
    )
    return _WHISPER

# =========================================================
# STT: Faster-Whisper, Urdu-only with retry for quality
# =========================================================
class UrduWhisperSTT(STT):
    """
    Urdu-only STT:
    - Forces language='ur' and task='transcribe'
    - Biases toward Urdu script via initial prompt; tries 'hotwords' if supported
    - Rejects ASCII-heavy outputs; retries once with stronger decode
    - Lazily loads Whisper if not prewarmed (fixes your crash)
    """
    def __init__(self):
        super().__init__(capabilities=STTCapabilities(streaming=False, interim_results=False))
        self._model = _load_whisper_if_needed()

    def _decode(self, audio: np.ndarray, beam_size: int, best_of: int, temperature: float):
        kwargs = dict(
            language="ur",
            task="transcribe",
            initial_prompt=_URDU_PROMPT,
            vad_filter=False,
            beam_size=beam_size,
            best_of=best_of,
            temperature=temperature,
            word_timestamps=False,
            condition_on_previous_text=False,
            no_speech_threshold=0.25,
            log_prob_threshold=-1.0,
            compression_ratio_threshold=2.5,
            without_timestamps=True,
        )
        # Add patience if using beam search (prevents "patience factor must be > 0")
        if beam_size and beam_size > 1:
            kwargs["patience"] = 1.0

        # Try with hotwords if this faster-whisper version supports it
        try:
            segments, _ = self._model.transcribe(audio, hotwords=_URDU_HOTWORDS, **kwargs)
        except TypeError:
            # Older faster-whisper: no hotwords param
            segments, _ = self._model.transcribe(audio, **kwargs)

        return " ".join(s.text.strip() for s in segments).strip()

    async def _recognize_impl(self, buffer, *, language=None, **kwargs) -> SpeechEvent:
        # Always Urdu
        wav_bytes = buffer.to_wav_bytes()
        import wave
        with wave.open(io.BytesIO(wav_bytes), "rb") as wf:
            sr, ch, _sw, n_frames = wf.getframerate(), wf.getnchannels(), wf.getsampwidth(), wf.getnframes()
            raw = wf.readframes(n_frames)

        pcm = np.frombuffer(raw, dtype=np.int16, count=n_frames * ch)
        audio = _resample_to_16k_mono(pcm, sr=sr, channels=ch)

        # Pass 1: balanced speed/quality
        text = self._decode(audio, beam_size=2, best_of=2, temperature=0.0)

        # If looks wrong (ASCII) or empty, retry stronger once
        if not text or _mostly_ascii(text):
            logging.info("[Urdu STT] ASCII-heavy/empty—retrying with stronger beam…")
            text = self._decode(audio, beam_size=5, best_of=1, temperature=0.0)

        logging.info(f"STT ▶ {text}")
        data = SpeechData(language="ur", text=text, confidence=0.0)
        return SpeechEvent(type=SpeechEventType.FINAL_TRANSCRIPT, alternatives=[data])

# =========================================================
# Agent (Urdu)
# =========================================================
class TalkAgent(Agent):
    def __init__(self) -> None:
        super().__init__(instructions=(
            "ہمیشہ اُردو میں مختصر اور فطری انداز میں جواب دیں۔ "
            "ضرورت کے بغیر انگریزی شامل نہ کریں۔"
        ))

# =========================================================
# (Optional) Prewarm — your LiveKit version may ignore this
# =========================================================
def prewarm(proc: agents.JobProcess):
    global _WHISPER, _VAD
    try:
        _VAD = silero.VAD.load()
    except Exception:
        _VAD = None
    _load_whisper_if_needed()

# =========================================================
# Entrypoint
# =========================================================
async def entrypoint(ctx: agents.JobContext):
    # LLM: Alif 3B (Ollama via OpenAI-compatible endpoint)
    llm = openai.LLM(
        model="hf.co/large-traversaal/Alif-1.0-3B-Instruct:Q4_K_M",
        base_url="http://localhost:11434/v1",
        api_key="ollama",
        temperature=0.2,
        max_completion_tokens=96,
    )

    # TTS: Azure multilingual (Urdu-capable)
    tts = azure.TTS(
        voice="en-US-AmandaMultilingualNeural"
    )

    # VAD
    vad = _VAD or silero.VAD.load()

    # STT: Urdu Whisper (lazy loads model if needed)
    stt = StreamAdapter(
        stt=UrduWhisperSTT(),
        vad=vad,
    )

    async with AgentSession(stt=stt, llm=llm, tts=tts) as session:
        await session.start(room=ctx.room, agent=TalkAgent(), room_input_options=RoomInputOptions())
        await session.say("السلام علیکم! میں حاضر ہوں—آپ اُردو میں بات کر سکتے ہیں۔", allow_interruptions=True)
        while True:
            await asyncio.sleep(1)

# =========================================================
# CLI
# =========================================================
if __name__ == "__main__":
    # Works even if your LiveKit version ignores prewarm_fnc,
    # because STT lazily loads the model now.
    agents.cli.run_app(WorkerOptions(entrypoint_fnc=entrypoint, prewarm_fnc=prewarm))
